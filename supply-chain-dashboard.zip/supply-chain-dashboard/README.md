# Supply chain dashboard

Supply-chain monitoring with **n8n, PostgreSQL, and Quadratic AI**. The n8n workflow generates purchase-order and inventory records. PostgreSQL calculates operational metrics, and the Quadratic workbook displays the latest imported snapshot. The recurring connection requires running n8n and PostgreSQL instances and a configured Quadratic workspace.

## Preview in Quadratic

1. Create a private Quadratic file. Import the four CSV files in `quadratic/snapshot/` as separate tables. Name the tables `SupplySummary`, `DeliveryTrend`, `OverdueOrders`, and `LowStock` to match the file names.
2. On a new sheet called **Dashboard**, select A1, press `/`, choose **Python**, paste `quadratic/dashboard.py`, and run the cell. It reads the first two named tables and displays the KPI cards, delivery trend, and source timestamp. The other two tables let you inspect the affected orders and stock.
3. Open **Quadratic AI Chat** and paste the relevant prompt from [Quadratic AI prompts](quadratic/ai-prompts.md). The preview stays fixed until you replace the CSV tables with live SQL outputs.

## Run the pipeline locally

With Docker and Docker Compose available, open Terminal in the extracted project folder and run:

```sh
./init-local-env.sh
docker compose up -d
```

1. Open [local n8n](http://localhost:5678) and complete its owner setup. Create a workflow and use **Import from File** to load `n8n/supply-chain-workflow.json`.
2. In **Load batch into PostgreSQL**, create a Postgres credential. Use host `postgres`, port `5432`, database `supply_chain`, user `supply_ingest`, and the `SUPPLY_INGEST_PASSWORD` from the generated `.env`. Use the local connection without SSL. The database is reachable from the n8n container through the private Compose network.
3. Use **Execute workflow** for the first batch. A fresh database should report **306 order lines** and **24 inventory positions** written. Publish the workflow to run every **15 minutes** while the n8n instance is running.
4. Inspect PostgreSQL with the command below. It returns the same metrics the workbook will query.

```sh
docker compose exec -T postgres psql -U postgres -d supply_chain \
  -c 'SELECT * FROM supply.dashboard_summary;'
```

Docker stores the data and n8n configuration in named volumes. `docker compose stop` pauses the pipeline and retains them.

## Connect a live, hosted Quadratic dashboard

1. Set up an always-on PostgreSQL service that accepts TLS connections from n8n and Quadratic, and use a project database dedicated to this project. Apply `postgres/01-schema.sql` as the database owner. Apply `postgres/02-access.sql` with `psql` and the reader and ingest passwords set in its local environment. Use a provider account that can create roles. Quadratic uses the read-only `supply_reader` role and n8n uses `supply_ingest`. [Quadratic PostgreSQL connection guide](https://docs.quadratichq.com/connections/postgresql)
2. Import the workflow on an always-on n8n instance or change the credential in the local instance. Point **Load batch into PostgreSQL** at the hosted server, enable validated TLS, execute once, and publish the workflow. A local instance runs only while your computer is awake and n8n is running. [n8n Schedule Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.scheduletrigger/)
3. In a new private Quadratic file, use **Connections → PostgreSQL** to connect with `supply_reader`. Run the four supplied SQL files in separate SQL cells on separate sheets. Name the resulting tables as shown below, then add `dashboard.py` to a Python cell on the **Dashboard** sheet. [Quadratic SQL cells](https://docs.quadratichq.com/connections/sql-getting-started)
4. In **Scheduled tasks**, run the **entire file** hourly at 5 minutes past the hour in Asia/Kolkata. Run it manually once, then check the next scheduled run and verify that **Source updated** advances. This is an hourly dashboard, with fresh database batches every 15 minutes. [Quadratic scheduled tasks](https://docs.quadratichq.com/spreadsheet/scheduled-tasks)

| SQL file | Quadratic table |
| --- | --- |
| `summary.sql` | `SupplySummary` |
| `delivery-trend.sql` | `DeliveryTrend` |
| `overdue-orders.sql` | `OverdueOrders` |
| `low-stock.sql` | `LowStock` |

## Metric definitions

- **Overdue PO lines** counts open, non-cancelled lines with a promised date before today in UTC. Partial deliveries stay open until the entire quantity is received.
- **On-time delivery · 30 days** divides lines completed by their promised date by all non-cancelled lines due in the previous 30 completed UTC dates. Open and late lines are in the denominator after their due date. A date with no due lines has a missing rate.
- **Low-stock positions** counts warehouse–SKU pairs with on-hand quantity below the reorder point. Each pair uses its most recent observation.
- **Source updated** shows the latest accepted batch timestamp. Each exception table also carries the underlying row timestamp.

## Replace the record generator with a source

Use a new database for operational data. The loader keeps one source label per database to prevent mixing records from different feeds. Replace the generator Code node with a node that fetches your future API, spreadsheet, or database, then map its fields to the same batch format. Prefer a timestamp from the source. Keep IDs stable across runs. An omitted row in an incremental batch retains its previous state, so send closures and cancellations explicitly.

```json
{
  "source_label": "Warehouse feed",
  "source_as_of": "2026-11-22T04:30:00Z",
  "orders": [
    {
      "order_id": "PO-1042",
      "line_number": 1,
      "supplier": "Sample supplier",
      "sku": "BX-110",
      "warehouse": "Mumbai",
      "ordered_qty": 100,
      "received_qty": 20,
      "promised_date": "2026-11-21",
      "completed_date": null,
      "cancelled": false
    }
  ],
  "inventory": [
    {
      "warehouse": "Mumbai",
      "sku": "BX-110",
      "on_hand_qty": 19,
      "reorder_point": 30
    }
  ]
}
```

Each batch is written atomically. Replays with the same timestamp leave existing rows unchanged, and older data cannot replace newer data for a key. Invalid quantities and duplicate keys in a batch fail the write. The sample data is illustrative and supports testing the pipeline.
