#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
umask 077
set -C
admin_password=$(openssl rand -hex 24)
ingest_password=$(openssl rand -hex 24)
reader_password=$(openssl rand -hex 24)
printf '%s\n' "SUPPLY_ADMIN_PASSWORD=$admin_password" \
              "SUPPLY_INGEST_PASSWORD=$ingest_password" \
              "SUPPLY_READER_PASSWORD=$reader_password" > .env
printf '%s\n' 'Created .env for the local pipeline.'
