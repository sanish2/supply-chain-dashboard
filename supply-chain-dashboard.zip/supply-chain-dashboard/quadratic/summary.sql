SELECT * FROM supply.dashboard_summary;
