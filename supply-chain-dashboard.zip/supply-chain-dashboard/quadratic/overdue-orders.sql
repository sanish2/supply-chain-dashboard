SELECT order_id, line_number, supplier, sku, warehouse, promised_date,
       days_overdue, outstanding_qty, source_as_of
FROM supply.overdue_orders
ORDER BY days_overdue DESC, outstanding_qty DESC, order_id, line_number;
