import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

summary = q.cells("SupplySummary[#ALL]").iloc[0]
trend = q.cells("DeliveryTrend[#ALL]").sort_values("promised_day")
rate = pd.to_numeric(trend["on_time_delivery_pct"], errors="coerce")
counts = trend[["lines_on_time", "lines_due"]].apply(pd.to_numeric, errors="coerce")

fig = make_subplots(
    rows=2,
    cols=3,
    specs=[[{"type": "indicator"}] * 3, [{"colspan": 3}, None, None]],
    subplot_titles=["", "", "", "On-time delivery by promised date"],
    row_heights=[0.32, 0.68],
    vertical_spacing=0.17,
)

metrics = (
    ("Overdue PO lines", summary["overdue_po_lines"], "", ",.0f"),
    ("On-time delivery · 30 days", summary["on_time_delivery_pct"], "%", ".1f"),
    ("Low-stock positions", summary["low_stock_positions"], "", ",.0f"),
)
for column, (label, value, suffix, number_format) in enumerate(metrics, start=1):
    available = pd.notna(value)
    fig.add_trace(go.Indicator(
        mode="number",
        value=float(value) if available else 0,
        title={"text": label},
        number={
            "suffix": suffix,
            "valueformat": number_format,
            "font": {"size": 42, "color": "#173D34" if available else "#FFFFFF"},
        },
    ), row=1, col=column)
    if not available:
        domain = fig.data[-1].domain
        fig.add_annotation(
            x=(domain.x[0] + domain.x[1]) / 2,
            y=(domain.y[0] + domain.y[1]) / 2,
            xref="paper", yref="paper", text="No eligible lines",
            showarrow=False, font={"color": "#4C615A", "size": 12},
        )

fig.add_trace(go.Scatter(
    x=pd.to_datetime(trend["promised_day"], errors="coerce"),
    y=rate, customdata=counts.to_numpy(),
    mode="lines+markers", connectgaps=False,
    line={"color": "#256C58", "width": 2.5},
    marker={"size": 5},
    hovertemplate="%{x|%d %b}<br>%{y:.1f}% on time<br>%{customdata[0]} of %{customdata[1]} due lines<extra></extra>",
), row=2, col=1)
fig.update_yaxes(range=[0, 105], ticksuffix="%", gridcolor="#E5EBE7", row=2, col=1)
fig.update_xaxes(tickformat="%d %b", showgrid=False, row=2, col=1)

timestamp = pd.to_datetime(summary["source_as_of"], utc=True, errors="coerce")
freshness = timestamp.strftime("%d %b %Y, %H:%M UTC") if pd.notna(timestamp) else "—"
fig.update_layout(
    title={"text": f"Supply chain dashboard<br><sup>Snapshot as of {freshness}</sup>", "x": 0.04},
    height=520, margin={"l": 68, "r": 32, "t": 105, "b": 52},
    paper_bgcolor="#FFFFFF", plot_bgcolor="#FFFFFF",
    font={"family": "Inter, Arial, sans-serif", "color": "#173D34"},
    showlegend=False,
)
fig
