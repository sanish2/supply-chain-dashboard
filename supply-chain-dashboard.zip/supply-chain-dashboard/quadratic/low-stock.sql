SELECT warehouse, sku, on_hand_qty, reorder_point, units_below_reorder, source_as_of
FROM supply.low_stock
ORDER BY units_below_reorder DESC, warehouse, sku;
