SELECT promised_day, lines_due, lines_on_time, on_time_delivery_pct
FROM supply.delivery_trend
ORDER BY promised_day;
