# Quadratic AI prompts

Use these after the workbook contains the four named tables. The SQL queries supply the KPI values. The AI helps explain and explore them. [Quadratic AI guide](https://docs.quadratichq.com/quadratic-ai/generate-code)

## Summarize what needs attention

> Read SupplySummary, DeliveryTrend, OverdueOrders, and LowStock. Give me a three-bullet operations brief. Report when the source was last updated, identify up to three specific overdue lines or low-stock positions to check first, and quote the days overdue, outstanding units, or units below reorder point. Use only values in the workbook. Use the source label to describe how the records were produced.

## Compare the current exception queues

> Build a table of overdue purchase-order lines and total outstanding units by supplier using OverdueOrders. Separately rank affected warehouse–SKU pairs using LowStock and units_below_reorder. Keep the two measures separate. Include only rows present in the workbook.

## Set the hourly refresh

> Set a scheduled task to run the entire workbook hourly at five minutes past the hour, Asia/Kolkata. Use the existing SQL queries and Python chart. Tell me the name and schedule of the task.
