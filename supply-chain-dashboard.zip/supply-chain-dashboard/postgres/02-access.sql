\set ON_ERROR_STOP on
\getenv ingest_password SUPPLY_INGEST_PASSWORD
\getenv reader_password SUPPLY_READER_PASSWORD

BEGIN;
CREATE ROLE supply_ingest LOGIN PASSWORD :'ingest_password';
CREATE ROLE supply_reader LOGIN PASSWORD :'reader_password';

GRANT USAGE ON SCHEMA supply TO supply_ingest, supply_reader;
GRANT EXECUTE ON FUNCTION supply.ingest_batch(jsonb) TO supply_ingest;
GRANT SELECT ON supply.dashboard_summary, supply.delivery_trend,
                supply.overdue_orders, supply.low_stock TO supply_reader;
COMMIT;
